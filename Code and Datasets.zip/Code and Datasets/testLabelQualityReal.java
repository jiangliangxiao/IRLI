package ceka.IRLI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

import IWMV.IWMV;
import ceka.DEWSMV.OptimizedEntropy;
import ceka.DEWSMV.OptimizedError;
import ceka.DEWSMV.OptimizedGini;
import ceka.consensus.*;
import ceka.consensus.kos.kos_jq;
import ceka.consensus.square.SquareIntegration;
import ceka.converters.FileLoader;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Worker;
import ceka.utils.PerformanceStatistic;
import weka.classifiers.trees.J48;
import weka.core.Utils;


/**
 * IRLI's label quality and running time
 * @author Zyao
 *
 */
public class testLabelQualityReal {
	public static int m_Times = 10;
	public static J48 m_classifier = new J48();
	
	public static void main(String[] args) throws Exception {
		// read datasets path
		String dataPath = "D:/Data/real/";
		String[] datasets = { "income", "leaves"};  	
				
		String resultAccPath = "D:/Data/testLabelQualityReal_accuracy.txt";
		String outputPath = "D:/Data/outputTemp/";
		FileOutputStream accFile = new FileOutputStream(new File(resultAccPath));
		PrintStream resultAcc = new PrintStream(accFile);
		resultAcc.println("                    MV               ZC               KOS              IWMV           DEWError        DEWGini      DEWEntropy        IRLI");
		
		String resultTimePath = "D:/Data/testLabelQualityReal_time.txt";
		FileOutputStream timeFile = new FileOutputStream(new File(resultTimePath));
		PrintStream resultTime = new PrintStream(timeFile);
		resultTime.println("                    MV               ZC               KOS              IWMV           DEWError        DEWGini      DEWEntropy        IRLI");

		
		PerformanceStatistic reporter = null;
		
		for (int nn = 0; nn < datasets.length; nn++) {
			resultAcc.format("%-15s", datasets[nn]);
			resultTime.format("%-15s", datasets[nn]);
			System.out.println(datasets[nn]);
				
			
			String responsepath = dataPath + datasets[nn] + ".response.txt";
			String goldpath = dataPath + datasets[nn] + ".gold.txt";
			String arffxpath = dataPath + datasets[nn] + ".arffx";			
			Dataset m_data = FileLoader.loadFileX(responsepath, goldpath, arffxpath);
			

			Dataset tempDataset = new Dataset(m_data);
			double[] mvresults = new double[m_Times];
			double[] zcresults = new double[m_Times];
			double[] kosresults = new double[m_Times];
			double[] iwmvresults = new double[m_Times];
			double[] DEWErrorresults = new double[m_Times];
			double[] DEWGiniresults = new double[m_Times];
			double[] DEWEntropyresults = new double[m_Times];
			double[] IRLIresults = new double[m_Times];
			
			double mvTime = 0;
			double zcTime = 0;
			double kosTime = 0;
			double iwmvTime = 0;
			double errorTime = 0;
			double giniTime = 0;
			double entropyTime = 0;
			double irliTime = 0;
			
			long now1 = 0L;
			long now2 = 0L;
			
			for (int times = 0; times < m_Times; times++) {
				
				// MV 
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				MajorityVote mv = new MajorityVote();
				mv.doInference(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				double acc = reporter.getAccuracy();
				mvresults[times] = acc * 100;
				mvTime += (now2 - now1);
				// ZC
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				SquareIntegration squareIntegration = new SquareIntegration(outputPath);
				squareIntegration.doInference(tempDataset, "Zen");
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				zcresults[times] = acc * 100;
				zcTime += (now2 - now1);
				// KOS
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				kos_jq kos = new kos_jq(20);
				kos.doInference(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				kosresults[times] = acc * 100;
				kosTime += (now2 - now1);
				//IWMV
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				IWMV iwmv = new IWMV();
				iwmv.doInference(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				iwmvresults[times] = acc * 100;
				iwmvTime += (now2 - now1);
				//DEWError
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				OptimizedError de_error = new OptimizedError();
				de_error.DE_search(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				DEWErrorresults[times] = acc * 100;
				errorTime += (now2 - now1);
				//DEWGini
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				OptimizedGini de_gini = new OptimizedGini();
				de_gini.DE_search(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				DEWGiniresults[times] = acc * 100;
				giniTime += (now2 - now1);
				//DEWEntropy
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				OptimizedEntropy de_entropy = new OptimizedEntropy();
				de_entropy.DE_search(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				DEWEntropyresults[times] = acc * 100;		
				entropyTime += (now2 - now1);
				// IRLI  
				tempDataset = copyDataset(m_data);
				now1 = System.currentTimeMillis();
				IRLI a = new IRLI();
				a.doInference(tempDataset);
				now2 = System.currentTimeMillis();
				reporter = new PerformanceStatistic();
				reporter.stat(tempDataset);
				acc = reporter.getAccuracy();
				IRLIresults[times] = acc * 100;
				irliTime += (now2 - now1);
				

			}
			resultAcc.format("%-10.2f       %-10.2f       %-10.2f       %-10.2f       %-10.2f     %-10.2f      %-10.2f      %-10.2f \n",
					Utils.mean(mvresults),Utils.mean(zcresults), Utils.mean(kosresults),Utils.mean(iwmvresults), Utils.mean(DEWErrorresults),
					Utils.mean(DEWGiniresults),Utils.mean(DEWEntropyresults),Utils.mean(IRLIresults));
	
			resultTime.format("%-10.4f       %-10.4f       %-10.4f       %-10.4f       %-10.4f     %-10.4f      %-10.4f      %-10.4f \n",
					mvTime, zcTime, kosTime, iwmvTime, errorTime, giniTime, entropyTime, irliTime);	
	
		}
		resultAcc.close();
		resultTime.close();
	}
	
	public static Dataset copyDataset(Dataset dataset) {
		Dataset copyDataset = new Dataset(dataset, 0);
		for (int k = 0; k < dataset.getExampleSize(); k++) {
			Example example = dataset.getExampleByIndex(k);
			copyDataset.addExample(example);
		}
		for (int k = 0; k < dataset.getCategorySize(); k++) {
			Category category = dataset.getCategory(k);
			copyDataset.addCategory(category);
		}
		for (int k = 0; k < dataset.getWorkerSize(); k++) {
			Worker worker = dataset.getWorkerByIndex(k);
			copyDataset.addWorker(worker);
		}
		return copyDataset;
	}

}
