package ceka.IRLI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Random;

import IWMV.IWMV;
import ceka.DEWSMV.OptimizedEntropy;
import ceka.DEWSMV.OptimizedError;
import ceka.DEWSMV.OptimizedGini;
import ceka.consensus.kos.kos_jq;
import ceka.consensus.square.SquareIntegration;
import ceka.converters.FileLoader;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Worker;
import ceka.simulation.MockWorker;
import ceka.simulation.SingleQualLabelingStrategy;
import weka.classifiers.trees.J48;
import weka.core.Utils;

public class testModelQualitySimu {
	public static int m_nfolds = 10;
	public static J48 m_classifier;
	public static weka.classifiers.Evaluation m_eval;
	
	public static void simulateDataset(Dataset data, int numworkers) {
		double max = 0.75;
		double min = 0.55;
		MockWorker[] mockWorkers = new MockWorker[numworkers];
		for (int j = 0; j < numworkers; j++) {
			double quality = Math.random() * (max - min) + min;
			SingleQualLabelingStrategy strategy = new SingleQualLabelingStrategy(quality);
			mockWorkers[j] = new MockWorker(String.valueOf(j));
			mockWorkers[j].setSingleQuality(quality);
			mockWorkers[j].labeling(data, strategy);
		}
	}
	
	
	public static void main(String[] args) throws Exception {
		// simulated datasets path
		String dataPath = "D:/Data/data34/";
		String[] datasets = { 				
				"anneal", "audiology", "autos", "balance-scale" , "biodeg", "breast-cancer", "breast-w",
				"car", "credit-a", "credit-g", "diabetes", "heart-c", "heart-h","heart-statlog", "hepatitis",
				"horse-colic", "hypothyroid", "ionosphere", 
				"iris", "kr-vs-kp","labor", "lymph", "mushroom","segment",
				"sick", "sonar", 
				"spambase", "tic-tac-toe", "vehicle", "vote", "vowel", "waveform", "zoo",	/**/			
				"letter"
		};


		String resultPath = "D:/Data/testModelQualitySimu.txt";
		String outputPath = "D:/Data/outputTemp/";
		FileOutputStream file = new FileOutputStream(new File(resultPath));
		PrintStream result = new PrintStream(file);
		result.println("                    ZC               KOS              IWMV           DEWError        DEWGini      DEWEntropy        IRLI");

		
		for (int nn = 0; nn < datasets.length; nn++) {
			result.format("%-15s", datasets[nn]);
			System.out.print(datasets[nn]+"    ");
						
			double[] zcresults = new double[m_nfolds];
			double[] kosresults = new double[m_nfolds];
			double[] iwmvresults = new double[m_nfolds];
			double[] DEWErrorresults = new double[m_nfolds];
			double[] DEWGiniresults = new double[m_nfolds];
			double[] DEWEntropyresults = new double[m_nfolds];
			double[] irliresults = new double[m_nfolds];
			double[] irlifeiresults = new double[m_nfolds];
			
			// read simulated datasets
			String dataArff = dataPath + datasets[nn] + ".arff";
			Dataset m_data = FileLoader.loadFile(dataArff);
			

			Dataset[]  splittedDatasets= crossSplitDataset(m_data, m_nfolds, true);
			Dataset tempDataset = null;
			
			for (int nFold = 0; nFold < m_nfolds; nFold++) {		
				Dataset [] trainAndTest = crosspickCombine(splittedDatasets, nFold);
				Dataset m_dataTrain = trainAndTest[0];
				Dataset m_dataTest = trainAndTest[1];
				
				simulateDataset(m_dataTrain, 7);
				
				
				// ZC
				tempDataset = copyDataset(m_dataTrain);
				SquareIntegration squareIntegration = new SquareIntegration(outputPath);
				squareIntegration.doInference(tempDataset, "Zen");
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				zcresults[nFold] = m_eval.pctCorrect();
				// KOS
				tempDataset = copyDataset(m_dataTrain);
				kos_jq kosjq = new kos_jq(20);
				kosjq.doInference(tempDataset);
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				kosresults[nFold] = m_eval.pctCorrect();
				//IWMV
				tempDataset = copyDataset(m_dataTrain);
				IWMV iwmv = new IWMV();
				iwmv.doInference(tempDataset);
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				iwmvresults[nFold] = m_eval.pctCorrect();
				//DEWError
				tempDataset = copyDataset(m_dataTrain);
				OptimizedError de_error = new OptimizedError();
				de_error.DE_search(tempDataset);
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				DEWErrorresults[nFold] = m_eval.pctCorrect();				
				//DEWGini
				tempDataset = copyDataset(m_dataTrain);
				OptimizedGini de_gini = new OptimizedGini();
				de_gini.DE_search(tempDataset);
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				DEWGiniresults[nFold] = m_eval.pctCorrect();
				//DEWEntropy
				tempDataset = copyDataset(m_dataTrain);
				OptimizedEntropy de_entropy = new OptimizedEntropy();
				de_entropy.DE_search(tempDataset);
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				DEWEntropyresults[nFold] = m_eval.pctCorrect();	
				//IRLI			
				tempDataset = copyDataset(m_dataTrain);
				IRLI a = new IRLI();
				a.doInference(tempDataset);
				m_classifier = new J48();
				m_classifier.buildClassifier(tempDataset);
				m_eval = new weka.classifiers.Evaluation(tempDataset);
				m_eval.evaluateModel(m_classifier, m_dataTest);
				irliresults[nFold] = m_eval.pctCorrect();
				
				
			}
			result.format("%-10.2f       %-10.2f       %-10.2f       %-10.2f     %-10.2f      %-10.2f      %-10.2f      %-10.2f\n", 
					Utils.mean(zcresults), Utils.mean(kosresults),Utils.mean(iwmvresults),Utils.mean(DEWErrorresults), 
					Utils.mean(DEWGiniresults),Utils.mean(DEWEntropyresults),Utils.mean(irliresults),Utils.mean(irlifeiresults));
			
		}
		result.close();
		
	}
	
	public static Dataset copyDataset(Dataset dataset) {
		Dataset copyDataset = new Dataset(dataset, 0);
		for (int k = 0; k < dataset.getExampleSize(); k++) {
			Example example = dataset.getExampleByIndex(k);
			copyDataset.addExample(example);
		}
		for (int k = 0; k < dataset.getCategorySize(); k++) {
			Category category = dataset.getCategory(k);
			copyDataset.addCategory(category);
		}
		for (int k = 0; k < dataset.getWorkerSize(); k++) {
			Worker worker = dataset.getWorkerByIndex(k);
			copyDataset.addWorker(worker);
		}
		return copyDataset;
	}
	
	public static Dataset [] crossSplitDataset(Dataset dataset, int nFold, boolean isShuffled) {
		Dataset [] datasets = new Dataset[nFold];
		int count = dataset.getExampleSize() / nFold;		
		int lastCount = count + dataset.getExampleSize() % nFold;
		if (isShuffled) {
			Random random = new Random();
			dataset.randomize(random);
		}
		for (int i = 0; i < nFold - 1; i++) {			
			datasets[i] = dataset.generateEmpty();			
			for (int c = 0; c < dataset.getCategorySize(); c++) {
				Category cate = dataset.getCategory(c);
				datasets[i].addCategory(cate.copy());
			}			
			for (int j = 0; j < count; j++){
				Example example = dataset.getExampleByIndex(i * count + j);
				datasets[i].addExample(example);
			}
		}
		datasets[nFold - 1]  = dataset.generateEmpty();
		for (int c = 0; c < dataset.getCategorySize(); c++) {
			Category cate = dataset.getCategory(c);
			datasets[nFold - 1].addCategory(cate.copy());
		}
		for (int j = 0; j < lastCount; j++) {
			int eindex = (nFold - 1) * count + j;
			Example example = dataset.getExampleByIndex(eindex);
			datasets[nFold - 1].addExample(example);
		}
		return datasets;
	}
	
	public static Dataset [] crosspickCombine(Dataset [] datasets, int select) {
		Dataset [] results = new Dataset[2];
		results[0] = datasets[0].generateEmpty();
		results[1] = datasets[0].generateEmpty();
		for (int i = 0; i < datasets[0].getCategorySize(); i++) {
			Category cate = datasets[0].getCategory(i);
			results[0].addCategory(cate.copy());
			results[1].addCategory(cate.copy());
		}
		
		for (int i = 0; i < datasets.length; i++)
			if (i != select)
				for (int j = 0; j < datasets[i].numInstances(); j++){					
					Example example = datasets[i].getExampleByIndex(j);
					results[0].addExample(example);
					String a = example.getId();
					
					for (int k = 0; k < example.getWorkerIdList().size(); k++) {
						String wID = example.getWorkerIdList().get(k);
						Worker worker = results[0].getWorkerById(wID);
						if (worker == null) {
							results[0].addWorker(worker = new Worker(wID));
						}
					}
				}
			else
				for (int j = 0; j < datasets[i].numInstances(); j++){
					Example example = datasets[i].getExampleByIndex(j);
					results[1].addExample(example);
					String a = example.getId();
					
					for (int k = 0; k < example.getWorkerIdList().size(); k++) {
						String wID = example.getWorkerIdList().get(k);
						Worker worker = results[1].getWorkerById(wID);
						if (worker == null) {
							results[1].addWorker(worker = new Worker(wID));
						}
					}
				}
		return results;
	}
	
}