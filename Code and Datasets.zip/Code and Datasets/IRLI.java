package ceka.IRLI;

import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.MultiNoisyLabelSet;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;


public class IRLI {
	private int m_numClasses = 0;
	private int m_numAttributes = 0;
	private int m_numExamples = 0;
	public double[][] m_instanceProb;
	private Dataset[] subDatasets;
	private Instances m_Centroids;
	private double[] m_MinArray;
	private double[] m_MaxArray;
	
	
	public void doInference(Dataset data) throws Exception {
		m_numClasses = data.numClasses();
		m_numExamples = data.getExampleSize();
		m_numAttributes = data.numAttributes();
		m_instanceProb = new double[data.getExampleSize()][m_numClasses];
		
		//Step 1
		calMNL(data);
		
		
		//Step 2
		divideSubsets(data);
		
		//Step 3
		m_Centroids = new Instances(data, m_numClasses);
		generateCentroids();
		
		//Step 4
		calSimilarity(data);
		
		
		// this is important
		data.assignIntegeratedLabel2WekaInstanceClassValue();
	}
	
	public void calMNL(Dataset data) {
		double[] exLable = null;
		for (int j = 0; j < data.getExampleSize(); j++) {
			exLable = new double[m_numClasses];
			Example ex = data.getExampleByIndex(j);
			MultiNoisyLabelSet labelSet = ex.getMultipleNoisyLabelSet(0);
			for (int m = 0; m < labelSet.getLabelSetSize(); m++) {
				int labelclass = labelSet.getLabel(m).getValue();
				exLable[labelclass]++;
			}
			Utils.normalize(exLable);			
			for(int k=0; k<m_numClasses; k++) {
				m_instanceProb[j][k] = exLable[k];
			}
			data.getExampleByIndex(j).setWeight(exLable[Utils.maxIndex(exLable)]);
			
			Integer maxIndex = Utils.maxIndex(exLable);
			Label integratedLabel = new Label(null, maxIndex.toString(), ex.getId(), "new");
			data.getExampleByIndex(j).setIntegratedLabel(integratedLabel);
		}
	}
	
	public void divideSubsets(Dataset data) {
		subDatasets = new Dataset[m_numClasses];
		for(int k=0; k<m_numClasses; k++) {
			subDatasets[k] = data.generateEmpty();
		}
		for(int i=0; i<data.getExampleSize(); i++) {
			int label = data.getExampleByIndex(i).getIntegratedLabel().getValue();
			subDatasets[label].addExample(data.getExampleByIndex(i));
		}
		
	}
	
	public void generateCentroids() {
		for(int k=0; k<m_numClasses; k++) {
			if(subDatasets[k].getExampleSize()==0) {
				m_Centroids.add(new Instance(m_numAttributes));
			}
			else if(subDatasets[k].getExampleSize()==1) {
				m_Centroids.add(new Instance(subDatasets[k].instance(0)));
			}
			else {
				double[] vals = new double[subDatasets[k].numAttributes()];
				for (int j = 0; j < m_numAttributes; j++) {
					vals[j] = subDatasets[k].meanOrMode(j);
				}
				m_Centroids.add(new Instance(1.0, vals));
			}
		}
		
	}
	
	public void calSimilarity(Dataset data) {		
		m_MinArray = new double[m_numAttributes];
		m_MaxArray = new double[m_numAttributes];
		for (int m = 0; m < m_numAttributes; m++)
			m_MinArray[m] = Double.NaN;
		for(int i=0; i<m_numExamples; i++) {
			double[] value = data.instance(i).toDoubleArray();
			for(int m=0; m<m_numAttributes; m++) {
				if(data.attribute(m).isNumeric() && (data.classIndex() != m)) {
					if (!Instance.isMissingValue(value[m])) {
						if (Double.isNaN(m_MinArray[m])) {
							m_MinArray[m] = m_MaxArray[m] = value[m];
						} else {
							if (value[m] < m_MinArray[m])
								m_MinArray[m] = value[m];
							if (value[m] > m_MaxArray[m])
								m_MaxArray[m] = value[m];
						}
					}					
				}
			}
		}
		
		for(int i=0; i<m_numExamples; i++) {
			Example ex = data.getExampleByIndex(i);
			double[] similarityProb = new double[m_numClasses];
			
			for(int k=0; k<m_numClasses; k++) {
				if(m_Centroids.instance(k).classIsMissing()) {
					similarityProb[k] = 0;
				}
				else {
					double dist = calHMOM(ex, m_Centroids.instance(k));
					double gamma = 0.5;
					similarityProb[k] = Math.exp(-dist*gamma);
				}								
			}
			Utils.normalize(similarityProb);
			
			for(int k=0; k<m_numClasses; k++) {
				similarityProb[k] += m_instanceProb[i][k];
			}
			int maxIndex = Utils.maxIndex(similarityProb);
			
			Utils.normalize(similarityProb);
			//update
			data.getExampleByIndex(i).setWeight(similarityProb[maxIndex]);
			data.getExampleByIndex(i).getIntegratedLabel().setValue(maxIndex);
		}
		
	}
	
	
	public double calHMOM(Instance ins1, Instance ins2) {
		double distance = 0;
		for(int m=0; m<m_numAttributes; m++) {
			if(m == ins1.classIndex()) continue;
			if(ins1.isMissing(m) || ins2.isMissing(m))
				distance += 1;
			else if(ins1.attribute(m).isNominal()) {
				distance += (ins1.value(m) == ins2.value(m)) ? 0 :1;
			}
			else {
				if((m_MaxArray[m] - m_MinArray[m]) == 0)
					distance += 0;
				else
					distance += Math.abs(ins1.value(m) - ins2.value(m)) / (m_MaxArray[m] - m_MinArray[m]);
			}
			
		}		
		
		return distance;
	}
	
	
}
